package assistedPractice;

class SleepThread extends Thread {
    public void run() {
        System.out.println("SleepThread is starting.");
        
        try {
            // Sleep for 3 seconds
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            System.out.println("SleepThread was interrupted.");
        }
        
        System.out.println("SleepThread is done.");
    }
}

class WaitThread extends Thread {
    private final Object lock;

    public WaitThread(Object lock) {
        this.lock = lock;
    }

    public void run() {
        System.out.println("WaitThread is starting.");
        
        synchronized (lock) {
            try {
                System.out.println("WaitThread is waiting for SleepThread to finish.");
                lock.wait(); // Wait until notified by SleepThread
            } catch (InterruptedException e) {
                System.out.println("WaitThread was interrupted.");
            }
            
            System.out.println("WaitThread is done.");
        }
    }
}

public class SleepWaitDemo {
    public static void main(String[] args) {
        Object lock = new Object();
        
        SleepThread sleepThread = new SleepThread();
        WaitThread waitThread = new WaitThread(lock);
        
        sleepThread.start();
        waitThread.start();
        
        try {
            // Sleep for a while to allow both threads to start
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            System.out.println("Main thread was interrupted.");
        }
        
        // Notify the WaitThread to continue
        synchronized (lock) {
            System.out.println("Main thread is notifying WaitThread.");
            lock.notify();
        }
        
        try {
            // Sleep to give time for WaitThread to finish
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            System.out.println("Main thread was interrupted.");
        }
        
        System.out.println("Main thread is done.");
    }
}
