package assistedPractice;

//Custom exception class
class CustomException extends Exception {
 public CustomException(String message) {
     super(message);
 }
}

public class ExceptionDemo {
 public static void main(String[] args) {
     try {
         // Call a method that throws an exception
         performDivideOperation(10, 0);
     } catch (ArithmeticException e) {
         // Catch the built-in ArithmeticException
         System.out.println("Caught ArithmeticException: " + e.getMessage());
     } catch (CustomException e) {
         // Catch a custom exception
         System.out.println("Caught CustomException: " + e.getMessage());
     } finally {
         // The finally block is executed regardless of whether an exception occurred
         System.out.println("Finally block executed.");
     }
 }

 // Method that throws an exception using the "throws" keyword
 public static void performDivideOperation(int numerator, int denominator) throws CustomException {
     try {
         if (denominator == 0) {
             // Throw a custom exception if the denominator is zero
             throw new CustomException("Division by zero is not allowed.");
         }
         int result = numerator / denominator;
         System.out.println("Result: " + result);
     } catch (ArithmeticException e) {
         // Catch and rethrow a built-in exception with a custom message
         throw new CustomException("An error occurred during division: " + e.getMessage());
     }
 }
}
