package assistedPractice;

import java.util.Scanner;

public class Exceptionhandling1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        try {
            System.out.print("Enter a number: ");
            int num = scanner.nextInt();
            
            int result = 10 / num;
            
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Error: Cannot divide by zero.");
        } catch (java.util.InputMismatchException e) {
            System.out.println("Error: Invalid input. Please enter a valid number.");
        } finally {
            System.out.println("Finally block executed.");
            scanner.close();
        }
        
        System.out.println("Program continues after exception handling.");
    }
}

