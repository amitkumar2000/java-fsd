package assistedPractice;

public class ExceptionHandling {

	public static void main(String[] args) {
        try {
            // Code that may throw an exception
            int result = divide(10, 0); // Attempting to divide by zero
            System.out.println("Result: " + result); // This line won't be reached
        } catch (ArithmeticException e) {
            // Catching and handling the specific exception (division by zero)
            System.out.println("An arithmetic exception occurred: " + e.getMessage());
        } finally {
            // This block is always executed, regardless of whether an exception occurred
            System.out.println("Finally block executed.");
        }
        
        System.out.println("Program continues after exception handling.");
    }

    public static int divide(int numerator, int denominator) {
        // Attempt to divide the numerator by the denominator
        return numerator / denominator;
    }
}
