package assistedPractice;

//Define an interface A with a method
interface A {
 void displayA();
}

//Define an interface B that extends A with a method
interface B extends A {
 void displayB();
}

//Define an interface C that extends A with a method
interface C extends A {
 void displayC();
}

//Define a class MyClass that implements B and C
class MyClass implements B, C {
 public void displayA() {
     System.out.println("Method from interface A");
 }

 public void displayB() {
     System.out.println("Method from interface B");
 }

 public void displayC() {
     System.out.println("Method from interface C");
 }
}

public class DiamondProblem {
 public static void main(String[] args) {
     MyClass myClass = new MyClass();
     
     // Call methods from interfaces A, B, and C
     myClass.displayA();
     myClass.displayB();
     myClass.displayC();
 }
}

