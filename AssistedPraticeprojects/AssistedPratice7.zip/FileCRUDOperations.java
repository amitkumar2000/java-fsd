package assistedPractice;

import java.io.*;

public class FileCRUDOperations {
    public static void main(String[] args) {
        // Specify the file name
        String fileName = "example.txt";

        // Create and write to a file
        createAndWriteFile(fileName);

        // Read and display the file content
        readFile(fileName);

        // Update the file content
        updateFile(fileName, "This is an updated line.");

        // Read and display the updated content
        readFile(fileName);

        // Delete the file
        deleteFile(fileName);
    }

    // Create and write to a file
    public static void createAndWriteFile(String fileName) {
        try {
            FileWriter writer = new FileWriter(fileName);
            writer.write("Hello, World!\n");
            writer.write("This is a Java file CRUD example.");
            writer.close();
            System.out.println("File '" + fileName + "' has been created and written to.");
        } catch (IOException e) {
            System.err.println("An error occurred: " + e.getMessage());
        }
    }

    // Read and display the file content
    public static void readFile(String fileName) {
        try {
            FileReader reader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(reader);
            System.out.println("\nReading from '" + fileName + "':");

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }

            bufferedReader.close();
            reader.close();
        } catch (IOException e) {
            System.err.println("An error occurred: " + e.getMessage());
        }
    }

    // Update the file content
    public static void updateFile(String fileName, String newContent) {
        try {
            FileWriter writer = new FileWriter(fileName, true); // Append mode
            writer.write("\n" + newContent);
            writer.close();
            System.out.println("\nFile '" + fileName + "' has been updated.");
        } catch (IOException e) {
            System.err.println("An error occurred: " + e.getMessage());
        }
    }

    // Delete the file
    public static void deleteFile(String fileName) {
        File file = new File(fileName);
        if (file.exists()) {
            if (file.delete()) {
                System.out.println("\nFile '" + fileName + "' has been deleted.");
            } else {
                System.err.println("\nFailed to delete the file.");
            }
        } else {
            System.err.println("\nThe file does not exist.");
        }
    }
}

