package assistedPractice;

//Define a class representing a 'Person'
class Person {
 // Attributes or fields (encapsulation)
 private String name;
 private int age;

 // Constructor (encapsulation)
 public Person(String name, int age) {
     this.name = name;
     this.age = age;
 }

 // Method to display information (abstraction)
 public void displayInfo() {
     System.out.println("Name: " + name);
     System.out.println("Age: " + age);
 }

 // Getters and setters (encapsulation)
 public String getName() {
     return name;
 }

 public void setName(String name) {
     this.name = name;
 }

 public int getAge() {
     return age;
 }

 public void setAge(int age) {
     if (age >= 0) {  // Age should be non-negative
         this.age = age;
     } else {
         System.out.println("Invalid age value");
     }
 }
}

//Define a class representing a 'Student' that inherits from 'Person'
class Student extends Person {
 private String studentId;

 // Constructor (inheritance)
 public Student(String name, int age, String studentId) {
     super(name, age); // Call the constructor of the superclass (Person)
     this.studentId = studentId;
 }

 // Method overriding (polymorphism)
 @Override
 public void displayInfo() {
     super.displayInfo(); // Call the displayInfo() method of the superclass (Person)
     System.out.println("Student ID: " + studentId);
 }
}

public class OOPDemo {
 public static void main(String[] args) {
     // Creating objects of 'Person' and 'Student' classes
     Person person = new Person("John Doe", 30);
     Student student = new Student("Alice Smith", 20, "12345");

     // Using methods and displaying information
     System.out.println("Person Information:");
     person.displayInfo();

     System.out.println("\nStudent Information:");
     student.displayInfo();

     // Changing attributes using setters
     person.setAge(35);
     student.setName("Bob Johnson");

     // Display updated information
     System.out.println("\nUpdated Person Information:");
     person.displayInfo();

     System.out.println("\nUpdated Student Information:");
     student.displayInfo();
 }
}
