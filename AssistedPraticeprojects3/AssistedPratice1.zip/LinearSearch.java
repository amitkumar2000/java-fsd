package com.datas;

public class LinearSearch {
    public static int linearSearch(int[] arr, int target) {
        // Iterate through the array
        for (int i = 0; i < arr.length; i++) {
            // If the current element is equal to the target, return its index
            if (arr[i] == target) {
                return i;
            }
        }
        // If the target is not found, return -1
        return -1;
    }

    public static void main(String[] args) {
        int[] array = { 5, 10, 15, 20, 25, 30 };
        int target = 20;

        // Call linearSearch to find the index of the target element
        int result = linearSearch(array, target);

        if (result != -1) {
            System.out.println("Element " + target + " found at index " + result);
        } else {
            System.out.println("Element " + target + " not found in the array.");
        }
    }
}
