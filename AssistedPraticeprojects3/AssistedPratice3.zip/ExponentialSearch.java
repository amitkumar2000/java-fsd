package com.datas;

public class ExponentialSearch {
    public static int exponentialSearch(int[] arr, int target) {
        int n = arr.length;
        
        // If the target is the first element, return 0
        if (arr[0] == target) {
            return 0;
        }
        
        // Find the range for binary search by doubling the index
        int i = 1;
        while (i < n && arr[i] <= target) {
            i *= 2;
        }
        
        // Perform binary search in the identified range
        return binarySearch(arr, target, i / 2, Math.min(i, n - 1));
    }
    
    public static int binarySearch(int[] arr, int target, int left, int right) {
        while (left <= right) {
            int mid = left + (right - left) / 2;
            
            if (arr[mid] == target) {
                return mid; // Target found, return its index
            }
            
            if (arr[mid] < target) {
                left = mid + 1; // Adjust the left bound
            } else {
                right = mid - 1; // Adjust the right bound
            }
        }
        
        return -1; // Target not found
    }

    public static void main(String[] args) {
        int[] sortedArray = { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20 };
        int target = 10;

        // Call exponentialSearch to find the index of the target element
        int result = exponentialSearch(sortedArray, target);

        if (result != -1) {
            System.out.println("Element " + target + " found at index " + result);
        } else {
            System.out.println("Element " + target + " not found in the array.");
        }
    }
}
