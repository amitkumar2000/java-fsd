package assistedPractice;

class ListNode {
    int data;
    ListNode next;

    public ListNode(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    private ListNode head;

    public LinkedList() {
        head = null;
    }

    // Method to insert a new node at the end of the linked list
    public void insert(int data) {
        ListNode newNode = new ListNode(data);

        if (head == null) {
            head = newNode;
        } else {
            ListNode current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Method to delete the first occurrence of a key in the linked list
    public void delete(int key) {
        if (head == null) {
            return; // List is empty, nothing to delete
        }

        if (head.data == key) {
            head = head.next; // Key is found at the head, so update the head
            return;
        }

        ListNode current = head;
        ListNode previous = null;

        while (current != null && current.data != key) {
            previous = current;
            current = current.next;
        }

        if (current != null) {
            // Key is found, so remove it
            previous.next = current.next;
        }
    }

    // Method to display the linked list
    public void display() {
        ListNode current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class DeleteFirstOccurrence {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();

        // Insert some elements into the linked list
        list.insert(10);
        list.insert(20);
        list.insert(30);
        list.insert(40);
        list.insert(50);

        System.out.println("Original Linked List:");
        list.display();

        int keyToDelete = 30;
        list.delete(keyToDelete);

        System.out.println("Linked List after deleting first occurrence of " + keyToDelete + ":");
        list.display();
    }
}
