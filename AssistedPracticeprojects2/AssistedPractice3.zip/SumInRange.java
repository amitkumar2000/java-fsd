package assistedPractice;

import java.util.Scanner;

public class SumInRange {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input the number of elements in the array
        System.out.print("Enter the number of elements (n): ");
        int n = scanner.nextInt();

        if (n <= 0) {
            System.out.println("The number of elements must be greater than 0.");
            return;
        }

        // Create an array to store the elements
        int[] arr = new int[n];

        // Input the elements of the array
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        // Input the range L and R
        System.out.print("Enter the range (L and R, where 0 <= L <= R <= n-1): ");
        int L = scanner.nextInt();
        int R = scanner.nextInt();

        // Validate the range
        if (L < 0 || R >= n || L > R) {
            System.out.println("Invalid range.");
            return;
        }

        // Calculate the sum of elements in the range [L, R]
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }

        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);

        scanner.close();
    }
}
