package assisted2;

class Node {
    int data;
    Node next;
    Node prev;

    public Node(int data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }
}

class DoublyLinkedList {
    private Node head;
    private Node tail;

    public DoublyLinkedList() {
        head = null;
        tail = null;
    }

    // Insert a new element at the end of the doubly linked list
    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    // Traverse and print the doubly linked list in forward direction
    public void traverseForward() {
        Node current = head;
        System.out.println("Forward traversal:");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    // Traverse and print the doubly linked list in backward direction
    public void traverseBackward() {
        Node current = tail;
        System.out.println("Backward traversal:");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }
}

public class DoublyLinkedListTraversal {
    public static void main(String[] args) {
        DoublyLinkedList dll = new DoublyLinkedList();

        // Insert elements into the doubly linked list
        dll.insert(10);
        dll.insert(20);
        dll.insert(30);
        dll.insert(40);

        // Traverse and print the doubly linked list in both directions
        dll.traverseForward();
        dll.traverseBackward();
    }
}

