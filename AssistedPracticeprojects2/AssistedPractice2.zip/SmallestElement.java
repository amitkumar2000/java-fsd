package assistedPractice;

import java.util.Arrays;

public class SmallestElement {
    public static int findFourthSmallest(int[] arr) {
        if (arr == null || arr.length < 4) {
            throw new IllegalArgumentException("Input array should contain at least four elements");
        }

        // Sort the array in ascending order
        Arrays.sort(arr);

        // The fourth smallest element is at index 3 (0-based indexing)
        return arr[3];
    }

    public static void main(String[] args) {
        int[] unsortedList = {12, 5, 3, 7, 19, 8, 15, 11};

        try {
            int fourthSmallest = findFourthSmallest(unsortedList);
            System.out.println("The fourth smallest element is: " + fourthSmallest);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }
}
