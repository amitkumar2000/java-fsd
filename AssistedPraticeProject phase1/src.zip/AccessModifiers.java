
public class AccessModifiers {
    
    
    public int publicField = 10;
    

    protected int protectedField = 20;
    
   
    int defaultField = 30;
    
    private int privateField = 40;
    
  
    public AccessModifiers() {
        System.out.println("Public constructor");
    }
   
    protected AccessModifiers(int x) {
        System.out.println("Protected constructor with parameter: " + x);
    }
   
    AccessModifiers(double y) {
        System.out.println("Default constructor with parameter: " + y);
    }

    private AccessModifiers(String str) {
        System.out.println("Private constructor with parameter: " + str);
    }
    
  
    public void publicMethod() {
        System.out.println("Public method");
    }
    
  
    protected void protectedMethod() {
        System.out.println("Protected method");
    }
    
    
    void defaultMethod() {
        System.out.println("Default method");
    }
    
    
    private void privateMethod() {
        System.out.println("Private method");
    }
    
    public static void main(String[] args) {
        
        AccessModifiers obj = new AccessModifiers();
        
        
        System.out.println(obj.publicField);
        System.out.println(obj.protectedField);
        System.out.println(obj.defaultField);
        System.out.println(obj.privateField); 
        
        obj.publicMethod();
        obj.protectedMethod();
        obj.defaultMethod();
        obj.privateMethod(); 
}
}
