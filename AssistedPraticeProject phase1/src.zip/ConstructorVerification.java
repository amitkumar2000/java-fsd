public class ConstructorVerification {
    
    
    public ConstructorVerification() {
        System.out.println("Default Constructor called.");
    }

   
    public ConstructorVerification(String message) {
        System.out.println("Parameterized Constructor called with message: " + message);
    }

    public ConstructorVerification(int value) {
        this("Hello"); 
        System.out.println("Parameterized Constructor called with value: " + value);
    }

    public static void main(String[] args) {
  

        ConstructorVerification obj1 = new ConstructorVerification();

        ConstructorVerification obj2 = new ConstructorVerification("Welcome!");

        ConstructorVerification obj3 = new ConstructorVerification(42);
    }
}
