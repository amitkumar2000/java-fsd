public class MethodVerification {
    
    
    public static void printHello() {
        System.out.println("Hello, World!");
    }

    
    public static int add(int a, int b) {
        return a + b;
    }

  
    public static double add(double a, double b) {
        return a + b;
    }

    
    public static int sum(int... numbers) {
        int total = 0;
        for (int num : numbers) {
            total += num;
        }
        return total;
    }

    public static void main(String[] args) {
       

     
        printHello();

        int result1 = add(5, 3);
        System.out.println("5 + 3 = " + result1);

        double result2 = add(2.5, 3.7);
        System.out.println("2.5 + 3.7 = " + result2);

       
        int total1 = sum(1, 2, 3, 4, 5);
        System.out.println("Sum of 1, 2, 3, 4, 5 = " + total1);

        int total2 = sum(10, 20, 30);
        System.out.println("Sum of 10, 20, 30 = " + total2);
    }
}
