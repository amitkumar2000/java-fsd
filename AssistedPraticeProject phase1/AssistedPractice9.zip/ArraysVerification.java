public class ArraysVerification {

    public static void main(String[] args) {
      

        
        int[] intArray = { 1, 2, 3, 4, 5 };

       
        double[] doubleArray;
        doubleArray = new double[] { 1.1, 2.2, 3.3, 4.4, 5.5 };

    
        String[] stringArray = new String[3];
        stringArray[0] = "Apple";
        stringArray[1] = "Banana";
        stringArray[2] = "Cherry";

     
        System.out.println("Accessing Array Elements:");
        System.out.println("intArray[2] = " + intArray[2]);
        System.out.println("doubleArray[4] = " + doubleArray[4]);
        System.out.println("stringArray[1] = " + stringArray[1]);


        System.out.println("\nIterating Through Arrays:");
        for (int i = 0; i < intArray.length; i++) {
            System.out.println("intArray[" + i + "] = " + intArray[i]);
        }

        for (double num : doubleArray) {
            System.out.println("doubleArray element: " + num);
        }

        for (String fruit : stringArray) {
            System.out.println("stringArray element: " + fruit);
        }
    }
}
